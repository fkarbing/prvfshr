export class MythicalMysfitProfile {
    mysfitId: string;
    name: string;
    species: string;
    age: number;
    goodevil: string;
    lawchaos: string;
    thumbImageUri: string;
}
