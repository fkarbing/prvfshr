import { MythicalMysfitProfile } from "./mythical-mysfit-profile";

export class MythicalMysfitResponse {
    mysfits: MythicalMysfitProfile[]
}
